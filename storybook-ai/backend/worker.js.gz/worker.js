const OPENAI = 'https://api.openai.com/v1';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
};

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors });
    const url = new URL(request.url);
    try {
      if (url.pathname === '/health') return json({ ok: true, service: 'storybook-ai' });
      if (!env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is not configured');
      if (request.method !== 'POST') return json({ error: 'Not found' }, 404);
      const body = await request.json();
      if (url.pathname === '/story') return json(await createStory(body, env));
      if (url.pathname === '/character') return json(await createCharacter(body, env));
      if (url.pathname === '/illustrate') return json(await illustrate(body, env));
      return json({ error: 'Not found' }, 404);
    } catch (e) {
      console.error(e);
      return json({ error: e?.message || 'Unknown server error' }, 500);
    }
  }
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8' }
  });
}

async function openai(path, env, init = {}) {
  const headers = new Headers(init.headers || {});
  headers.set('Authorization', `Bearer ${env.OPENAI_API_KEY}`);
  const res = await fetch(OPENAI + path, { ...init, headers });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!res.ok) throw new Error(data?.error?.message || `OpenAI HTTP ${res.status}`);
  return data;
}

async function createStory(p, env) {
  const pageCount = clamp(Number(p.pageCount || 12), 6, 20);
  const childName = clean(p.childName, 80) || 'Ребёнок';
  const age = clamp(Number(p.age || 3), 2, 12);
  const prompt = `Создай оригинальную персональную детскую историю на русском языке.
Главный герой: ${childName}, ${age} лет.
Интересы: ${clean(p.interests, 700)}.
Характер: ${clean(p.character, 400)}.
Семья/питомцы/игрушки, которых можно органично добавить: ${clean(p.family, 500)}.
Пожелания родителя: ${clean(p.wishes, 700)}.
Тема: ${clean(p.theme, 100)}.
Стиль будущих иллюстраций: ${clean(p.style, 120)}.
Нужно ровно ${pageCount} страниц истории, плюс название и подзаголовок. Для ${age}-летнего ребёнка делай короткий, ясный, добрый текст. Каждая страница — самостоятельный визуально понятный эпизод. Никакого опасного поведения, жестокости, тяжёлых тем и пугающих сцен. У истории должны быть завязка, понятная цель, 2–3 маленьких препятствия, тёплая развязка и спокойный финал. Не упоминай, что история создана ИИ.
Поле scene должно подробно описывать только то, что нужно нарисовать на странице, включая позу героя, окружение, второстепенных персонажей и композицию. Не рисуй и не проси рисовать текст внутри изображения.`;

  const schema = {
    type: 'object',
    properties: {
      title: { type: 'string' },
      subtitle: { type: 'string' },
      character: { type: 'string' },
      pages: {
        type: 'array',
        minItems: pageCount,
        maxItems: pageCount,
        items: {
          type: 'object',
          properties: {
            number: { type: 'integer' },
            text: { type: 'string' },
            scene: { type: 'string' },
            mood: { type: 'string' }
          },
          required: ['number', 'text', 'scene', 'mood'],
          additionalProperties: false
        }
      }
    },
    required: ['title', 'subtitle', 'character', 'pages'],
    additionalProperties: false
  };

  const out = await openai('/responses', env, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: env.TEXT_MODEL || 'gpt-5.6-terra',
      store: false,
      input: prompt,
      reasoning: { effort: 'low' },
      text: { format: { type: 'json_schema', name: 'personal_storybook', strict: true, schema } }
    })
  });
  if (!out.output_text) throw new Error('Text model returned no story');
  const story = JSON.parse(out.output_text);
  story.pages = story.pages.slice(0, pageCount).map((x, i) => ({ ...x, number: i + 1 }));
  return story;
}

async function createCharacter(p, env) {
  if (!Array.isArray(p.photos) || p.photos.length === 0) throw new Error('No photos supplied');
  const prompt = `Use the supplied real child photos only as identity references. Create a clean, full-body character reference illustration for a children's picture book. Preserve the child's recognizable facial structure, hair, skin tone and age. Keep proportions age-appropriate and natural. Outfit: simple, colorful, neutral adventure clothes unless the photos clearly suggest something else. Illustration style: ${clean(p.style, 150)}. Neutral light background, full body visible, friendly expression, no text, no logos, no additional people, no adult-looking changes. This image will be used as the sole visual identity reference for all later pages.`;
  const refs = p.photos.slice(0, 4);
  let response;
  try {
    const form = new FormData();
    form.append('model', env.IMAGE_MODEL || 'gpt-image-2');
    form.append('prompt', prompt);
    form.append('size', '1024x1536');
    form.append('quality', 'medium');
    refs.forEach((d, i) => form.append('image[]', dataUrlToBlob(d), `ref-${i + 1}.jpg`));
    response = await openai('/images/edits', env, { method: 'POST', body: form });
  } catch (e) {
    // Compatibility fallback for APIs/SDK gateways that accept one `image` field.
    const form = new FormData();
    form.append('model', env.IMAGE_MODEL || 'gpt-image-2');
    form.append('prompt', prompt);
    form.append('size', '1024x1536');
    form.append('quality', 'medium');
    form.append('image', dataUrlToBlob(refs[0]), 'reference.jpg');
    response = await openai('/images/edits', env, { method: 'POST', body: form });
  }
  return { image: await imageResult(response) };
}

async function illustrate(payload, env) {
  const p = payload.profile || {};
  const page = payload.page || {};
  const identity = payload.referenceImage;
  const prompt = `Create one finished full-page children's picture-book illustration in portrait orientation.
Main character: ${clean(p.childName, 80)}, age ${clamp(Number(p.age || 3), 2, 12)}. If an identity reference image is attached, preserve that exact child's recognizable identity, apparent age, hair and character design consistently.
Scene: ${clean(page.scene, 1800)}
Mood: ${clean(page.mood, 300)}
Art direction: ${clean(p.style, 180)}. Theme: ${clean(p.theme, 120)}.
Composition must leave some calm visual space near the lower part of the page for book typography, but DO NOT render any text, letters, captions, logos, UI or watermark inside the image. Child-safe, warm, expressive, high-quality children's publishing illustration. Keep hands and anatomy natural. Avoid scary or violent imagery.`;

  let result;
  if (identity) {
    const form = new FormData();
    form.append('model', env.IMAGE_MODEL || 'gpt-image-2');
    form.append('prompt', prompt);
    form.append('size', '1024x1536');
    form.append('quality', 'medium');
    form.append('image', dataUrlToBlob(identity), 'character-reference.png');
    result = await openai('/images/edits', env, { method: 'POST', body: form });
  } else {
    result = await openai('/images/generations', env, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: env.IMAGE_MODEL || 'gpt-image-2', prompt, size: '1024x1536', quality: 'medium' })
    });
  }
  return { image: await imageResult(result) };
}

async function imageResult(r) {
  const item = r?.data?.[0];
  if (item?.b64_json) return `data:image/png;base64,${item.b64_json}`;
  if (item?.url) {
    const res = await fetch(item.url);
    if (!res.ok) throw new Error('Generated image could not be downloaded');
    const bytes = new Uint8Array(await res.arrayBuffer());
    return `data:image/png;base64,${bytesToBase64(bytes)}`;
  }
  throw new Error('Image model returned no image');
}

function dataUrlToBlob(dataUrl) {
  const m = /^data:([^;]+);base64,(.+)$/.exec(String(dataUrl || ''));
  if (!m) throw new Error('Invalid image data');
  const bin = atob(m[2]);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: m[1] || 'image/jpeg' });
}

function bytesToBase64(bytes) {
  let out = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) out += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(out);
}

function clean(v, max = 500) { return String(v ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max); }
function clamp(n, min, max) { return Math.max(min, Math.min(max, Number.isFinite(n) ? n : min)); }
