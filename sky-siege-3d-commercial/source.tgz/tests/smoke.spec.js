import { test, expect } from '@playwright/test';

const sdkMock=`
window.__ysdk={ready:0,start:0,stop:0};
window.YaGames={init:async()=>({
  getPlayer:async()=>({getData:async()=>({}),setData:async()=>{}}),
  features:{LoadingAPI:{ready:()=>{window.__ysdk.ready++}},GameplayAPI:{start:()=>{window.__ysdk.start++},stop:()=>{window.__ysdk.stop++}}},
  adv:{
    showFullscreenAdv:({callbacks})=>{callbacks.onOpen?.();setTimeout(()=>callbacks.onClose?.(true),10)},
    showRewardedVideo:({callbacks})=>{callbacks.onOpen?.();callbacks.onRewarded?.();setTimeout(()=>callbacks.onClose?.(),10)}
  },
  on:()=>{},off:()=>{}
})};
`;

test.beforeEach(async ({page})=>{
  await page.route('**/sdk.js',route=>route.fulfill({status:200,contentType:'application/javascript',body:sdkMock}));
  const errors=[];page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.__errors=errors;
});

test.afterEach(async ({page})=>{expect(page.__errors||[],'No uncaught browser/console errors').toEqual([])});

test('menu, campaign and a real 3D battle boot',async({page},testInfo)=>{
  await page.goto('/');
  await expect(page.locator('#main-menu')).toHaveClass(/visible/);
  expect(await page.evaluate(()=>window.__ysdk?.ready)).toBe(1);
  await expect(page.locator('#btn-campaign')).toBeVisible();
  await page.locator('#btn-campaign').click();
  await expect(page.locator('#campaign')).toHaveClass(/visible/);
  await expect(page.locator('.level-card')).toHaveCount(10);
  await page.locator('.level-card').first().click();
  await expect(page.locator('#hud')).toHaveClass(/visible/);
  await expect(page.locator('#hud-enemies')).not.toHaveText('0');
  expect(await page.locator('#ammo-dock .ammo-slot').count()).toBeGreaterThan(0);
  await page.screenshot({path:testInfo.outputPath('battle.png'),fullPage:true});
  const box=await page.locator('#game-canvas').boundingBox();expect(box).toBeTruthy();
  const x=box.x+box.width*.25,y=box.y+box.height*.55;
  await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+box.width*.18,y-box.height*.06,{steps:8});await page.mouse.up();
  await expect(page.locator('#ability-btn')).toHaveClass(/active/);
  await page.waitForTimeout(700);
  await page.screenshot({path:testInfo.outputPath('flight.png'),fullPage:true});
});
